#!/bin/sh
#
# shell script to create templates

cp ../source/jcl.template.inc ../source/jclc5.inc
cp ../source/jcl.template.inc ../source/jclc6.inc
cp ../source/jcl.template.inc ../source/jclkc3.inc
cp ../source/jcl.template.inc ../source/jclkd3.inc
cp ../source/jcl.template.inc ../source/jcld5.inc
cp ../source/jcl.template.inc ../source/jcld6.inc
cp ../source/jcl.template.inc ../source/jcld7.inc
cp ../source/jcl.template.inc ../source/jclcs1.inc
cp ../source/jcl.template.inc ../source/jcld8.inc
cp ../source/jcl.template.inc ../source/jcld9.inc
cp ../source/jcl.template.inc ../source/jcld9.net.inc
cp ../source/jcl.template.inc ../source/jcld10.inc
cp ../source/jcl.template.inc ../source/jcld10.net.inc
cp ../source/jcl.template.inc ../source/jcld11.inc
cp ../source/jcl.template.inc ../source/jcld11.net.inc